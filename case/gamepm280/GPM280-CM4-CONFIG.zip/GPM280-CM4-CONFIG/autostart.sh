#emulationstation #auto
emulationstation --screenrotate 3 --screensize 640 480
